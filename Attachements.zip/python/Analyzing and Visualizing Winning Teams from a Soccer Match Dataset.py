#This Python script utilizes the pandas and matplotlib libraries to analyze and visualize data from a soccer match results dataset. It begins by loading the dataset from a CSV file, extracting a list of distinctive teams participating as either home or away teams. The script then calculates the number of wins for each team by iterating through the dataset and updating a dictionary with win counts based on match outcomes. After converting this dictionary into a DataFrame and sorting it by the number of wins in descending order, the script prints the ranked list of teams. Finally, it creates a bar graph using matplotlib to visually represent the top 50 teams with the highest number of wins, providing a clear graphical overview of team performance based on the dataset.

import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
file_path = '/content/sample_data/results.csv'
data = pd.read_csv(file_path)

# List of distinctive teams from home_team and away_team
home_teams = data['home_team'].unique()
away_teams = data['away_team'].unique()
distinctive_teams = pd.concat([pd.Series(home_teams), pd.Series(away_teams)]).unique()

print("List of distinctive teams:")
print(distinctive_teams)

# Calculate the number of winning matches for each team
win_counts = {team: 0 for team in distinctive_teams}

# Iterate through the dataset to count wins
for _, row in data.iterrows():
    if row['home_score'] > row['away_score']:
        win_counts[row['home_team']] += 1
    elif row['away_score'] > row['home_score']:
        win_counts[row['away_team']] += 1

# Convert the dictionary to a DataFrame and sort by the number of wins
win_counts_df = pd.DataFrame(list(win_counts.items()), columns=['team', 'wins'])
win_counts_df = win_counts_df.sort_values(by='wins', ascending=False)

print("\nTeams ranked by number of wins:")
print(win_counts_df)

# Draw a graph to represent the best 50 teams
top_50_teams = win_counts_df.head(50)

plt.figure(figsize=(14, 7))
plt.bar(top_50_teams['team'], top_50_teams['wins'], color='blue')
plt.xlabel('Teams')
plt.ylabel('Number of Wins')
plt.title('Top 50 Teams by Number of Wins')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()
