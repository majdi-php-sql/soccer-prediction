#Description: This Python script analyzes historical football match data, specifically focusing on calculating score differences between home and away teams every 4 years. Using pandas for data manipulation, the script first loads a dataset containing match details such as dates, teams, scores, and tournaments. It then aggregates the total goals scored by each team during each 4-year period, computes the difference between home and away scores, and outputs this information into a new CSV file named 'differences.csv'. This analysis provides insights into team performance trends over time, highlighting periods of dominance or parity in football matches.

import pandas as pd

# Load the dataset
dataset_path = '/content/sample_data/results.csv'
df = pd.read_csv(dataset_path)

# Convert 'date' column to datetime format
df['date'] = pd.to_datetime(df['date'])

# Calculate score differences every 4 years
df['year'] = df['date'].dt.year
df['year_rounded'] = df['year'] // 4 * 4
team_diffs = df.groupby(['year_rounded', 'home_team'])[['home_score', 'away_score']].sum().reset_index()
team_diffs['score_difference'] = team_diffs['home_score'] - team_diffs['away_score']

# Select relevant columns for output
output_df = team_diffs[['year_rounded', 'home_team', 'score_difference']]

# Write to CSV
output_csv_path = '/content/sample_data/differences.csv'
output_df.to_csv(output_csv_path, index=False)

print(f"CSV file 'differences.csv' has been generated with team name and score differences every 4 years.")
