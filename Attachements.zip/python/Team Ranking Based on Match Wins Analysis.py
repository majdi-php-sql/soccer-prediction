#In this Python script utilizing the Pandas library, we load and analyze a dataset ('results.csv') containing football match results. Our objective is to determine a ranking of teams based on the total number of wins recorded. The script first identifies all distinct teams involved in matches, calculates the number of wins for each team by iterating through the dataset, and then constructs a DataFrame sorted by the number of wins. Finally, it ranks the teams and saves the results to a new CSV file ('ranks.csv'), providing a clear, sorted list of teams based on their performance. This approach offers a straightforward method for creating customized rankings independent of official FIFA rankings, emphasizing team success in competitive matches.

import pandas as pd

# Load the dataset
file_path = '/content/sample_data/results.csv'
data = pd.read_csv(file_path)

# List of distinctive teams from home_team and away_team
home_teams = data['home_team'].unique()
away_teams = data['away_team'].unique()
distinctive_teams = pd.concat([pd.Series(home_teams), pd.Series(away_teams)]).unique()

# Calculate the number of winning matches for each team
win_counts = {team: 0 for team in distinctive_teams}

# Iterate through the dataset to count wins
for _, row in data.iterrows():
    if row['home_score'] > row['away_score']:
        win_counts[row['home_team']] += 1
    elif row['away_score'] > row['home_score']:
        win_counts[row['away_team']] += 1

# Convert the dictionary to a DataFrame and sort by the number of wins
win_counts_df = pd.DataFrame(list(win_counts.items()), columns=['Team', 'Wins'])
win_counts_df = win_counts_df.sort_values(by='Wins', ascending=False).reset_index(drop=True)

# Rank the teams based on number of wins
win_counts_df['Rank'] = win_counts_df.index + 1

# Display the table sorted by rank (best to worst)
print("Ranking of Teams based on Number of Wins:")
print(win_counts_df[['Rank', 'Team', 'Wins']])

# Save the result to a CSV file in the same path
output_file = '/content/sample_data/ranks.csv'
win_counts_df.to_csv(output_file, index=False)
print(f"Results saved to '{output_file}' successfully.")
