<?php
require_once 'vendor/autoload.php';
use Phpml\Classification\KNearestNeighbors;

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "soccer_prediction";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch team options for dropdowns
function fetchTeamOptions() {
    global $conn;
    $sql = "SELECT DISTINCT home_team FROM results UNION SELECT DISTINCT away_team FROM results";
    $result = $conn->query($sql);
    $options = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $options[] = $row['home_team'];
        }
    }
    return $options;
}

// Function to fetch historical data for training the model
function fetchTrainingData() {
    global $conn;
    $sql = "SELECT home_team, away_team, home_score, away_score FROM results";
    $result = $conn->query($sql);
    $samples = [];
    $labels = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $samples[] = [$row['home_team'], $row['away_team']];
            $labels[] = ($row['home_score'] > $row['away_score']) ? 'Win' : (($row['home_score'] < $row['away_score']) ? 'Loss' : 'Draw');
        }
    }
    return [$samples, $labels];
}

// Function to calculate additional statistics
function calculateStatistics($team) {
    global $conn;
    $sql = "SELECT 
                COUNT(*) AS total_matches, 
                SUM(CASE WHEN home_team = '$team' THEN home_score ELSE away_score END) AS total_goals 
            FROM results 
            WHERE home_team = '$team' OR away_team = '$team'";
    $result = $conn->query($sql);
    $stats = $result->fetch_assoc();
    return $stats;
}

// Function to train the AI model (K-Nearest Neighbors)
function trainModel() {
    list($samples, $labels) = fetchTrainingData();

    // Encode team names to numeric values
    $teamMapping = array_flip(array_unique(array_merge(...$samples)));
    $numericSamples = array_map(function($sample) use ($teamMapping) {
        return [$teamMapping[$sample[0]], $teamMapping[$sample[1]]];
    }, $samples);

    // Initialize and train the model
    $classifier = new KNearestNeighbors();
    $classifier->train($numericSamples, $labels);

    return [$classifier, $teamMapping];
}

// Function to predict match outcome using the AI model
function predictMatchOutcome($first_team, $second_team) {
    list($classifier, $teamMapping) = trainModel();

    // Encode team names to numeric values
    $first_team_num = $teamMapping[$first_team];
    $second_team_num = $teamMapping[$second_team];

    // Predict the outcome based on the teams
    $prediction = $classifier->predict([$first_team_num, $second_team_num]);

    // Calculate win, loss, and draw percentages (example logic)
    $win_percentage = ($prediction === 'Win') ? 50 : 25;
    $loss_percentage = ($prediction === 'Loss') ? 50 : 25;

    return [
        'first_team_percentage' => $win_percentage,
        'second_team_percentage' => $loss_percentage,
        'draw_percentage' => 100 - ($win_percentage + $loss_percentage),
    ];
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['first_team']) && isset($_POST['second_team'])) {
    $first_team = $conn->real_escape_string($_POST['first_team']);
    $second_team = $conn->real_escape_string($_POST['second_team']);

    if ($first_team === $second_team) {
        echo json_encode(['error' => 'Please select different teams.']);
        exit;
    }

    // Predict match outcome
    $prediction = predictMatchOutcome($first_team, $second_team);

    // Fetch additional statistics
    $first_team_stats = calculateStatistics($first_team);
    $second_team_stats = calculateStatistics($second_team);

    // Prepare and send response
    $response = [
        'first_team_percentage' => $prediction['first_team_percentage'],
        'second_team_percentage' => $prediction['second_team_percentage'],
        'draw_percentage' => $prediction['draw_percentage'],
        'first_team_total_matches' => $first_team_stats['total_matches'],
        'second_team_total_matches' => $second_team_stats['total_matches'],
        'first_team_total_goals' => $first_team_stats['total_goals'],
        'second_team_total_goals' => $second_team_stats['total_goals'],
    ];

    echo json_encode($response);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Soccer Match Predictor</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Soccer Match Predictor</h1>
    <form id="predictionForm" method="POST">
        <label for="first_team">First Team:</label>
        <select name="first_team" id="first_team">
            <?php
            $options = fetchTeamOptions();
            foreach ($options as $option) {
                echo "<option value=\"$option\">$option</option>";
            }
            ?>
        </select>
        <br>
        <label for="second_team">Second Team:</label>
        <select name="second_team" id="second_team">
            <?php
            foreach ($options as $option) {
                echo "<option value=\"$option\">$option</option>";
            }
            ?>
        </select>
        <br>
        <button type="submit">Predict</button>
    </form>
    <div id="result"></div>
    <script>
        document.getElementById('predictionForm').addEventListener('submit', function(event) {
            event.preventDefault();
            var firstTeam = document.getElementById('first_team').value;
            var secondTeam = document.getElementById('second_team').value;

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'first_team=' + encodeURIComponent(firstTeam) + '&second_team=' + encodeURIComponent(secondTeam),
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    document.getElementById('result').innerHTML = `<p>${data.error}</p>`;
                } else {
                    document.getElementById('result').innerHTML = `
                        <p>First Team Winning Percentage: ${data.first_team_percentage}%</p>
                        <p>Second Team Winning Percentage: ${data.second_team_percentage}%</p>
                        <p>Draw Percentage: ${data.draw_percentage}%</p>
                        <p>Additional Statistics:</p>
                        <ul>
                            <li>Total Matches - First Team: ${data.first_team_total_matches}</li>
                            <li>Total Matches - Second Team: ${data.second_team_total_matches}</li>
                            <li>Total Goals - First Team: ${data.first_team_total_goals}</li>
                            <li>Total Goals - Second Team: ${data.second_team_total_goals}</li>
                        </ul>
                    `;
                }
            });
        });
    </script>
</body>
</html>
