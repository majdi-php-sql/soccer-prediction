<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "soccer_prediction";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch team options for dropdowns
function fetchTeamOptions() {
    global $conn;
    $sql = "SELECT DISTINCT home_team FROM results UNION SELECT DISTINCT away_team FROM results";
    $result = $conn->query($sql);
    $options = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $options[] = $row['home_team'];
        }
    }
    return $options;
}

// Calculate statistics for prediction
function calculatePrediction($first_team, $second_team) {
    global $conn;

    // Calculate total matches for each team
    $first_team_total_matches_query = "SELECT 
        COUNT(*) AS total_matches
        FROM results
        WHERE home_team = '$first_team' OR away_team = '$first_team'";
    $first_team_total_matches_result = $conn->query($first_team_total_matches_query);
    $first_team_total_matches = $first_team_total_matches_result->fetch_assoc()['total_matches'];

    $second_team_total_matches_query = "SELECT 
        COUNT(*) AS total_matches
        FROM results
        WHERE home_team = '$second_team' OR away_team = '$second_team'";
    $second_team_total_matches_result = $conn->query($second_team_total_matches_query);
    $second_team_total_matches = $second_team_total_matches_result->fetch_assoc()['total_matches'];

    // Calculate total goals for each team
    $first_team_total_goals_query = "SELECT 
        SUM(CASE WHEN home_team = '$first_team' THEN home_score ELSE 0 END) +
        SUM(CASE WHEN away_team = '$first_team' THEN away_score ELSE 0 END) AS total_goals
        FROM results";
    $first_team_total_goals_result = $conn->query($first_team_total_goals_query);
    $first_team_total_goals = $first_team_total_goals_result->fetch_assoc()['total_goals'];

    $second_team_total_goals_query = "SELECT 
        SUM(CASE WHEN home_team = '$second_team' THEN home_score ELSE 0 END) +
        SUM(CASE WHEN away_team = '$second_team' THEN away_score ELSE 0 END) AS total_goals
        FROM results";
    $second_team_total_goals_result = $conn->query($second_team_total_goals_query);
    $second_team_total_goals = $second_team_total_goals_result->fetch_assoc()['total_goals'];

    // Calculate tournament matches for each team (excluding Friendly and World Cup)
    $first_team_tournament_matches_query = "SELECT 
        COUNT(*) AS total_matches
        FROM results
        WHERE (home_team = '$first_team' OR away_team = '$first_team') 
        AND tournament NOT IN ('Friendly', 'FIFA World Cup')";
    $first_team_tournament_matches_result = $conn->query($first_team_tournament_matches_query);
    $first_team_tournament_matches = $first_team_tournament_matches_result->fetch_assoc()['total_matches'];

    $second_team_tournament_matches_query = "SELECT 
        COUNT(*) AS total_matches
        FROM results
        WHERE (home_team = '$second_team' OR away_team = '$second_team') 
        AND tournament NOT IN ('Friendly', 'FIFA World Cup')";
    $second_team_tournament_matches_result = $conn->query($second_team_tournament_matches_query);
    $second_team_tournament_matches = $second_team_tournament_matches_result->fetch_assoc()['total_matches'];

    // Calculate wins and losses for each team
    $first_team_wins_query = "SELECT 
        COUNT(*) AS wins
        FROM results
        WHERE (home_team = '$first_team' AND home_score > away_score) 
        OR (away_team = '$first_team' AND away_score > home_score)";
    $first_team_wins_result = $conn->query($first_team_wins_query);
    $first_team_wins = $first_team_wins_result->fetch_assoc()['wins'];

    $first_team_losses_query = "SELECT 
        COUNT(*) AS losses
        FROM results
        WHERE (home_team = '$first_team' AND home_score < away_score) 
        OR (away_team = '$first_team' AND away_score < home_score)";
    $first_team_losses_result = $conn->query($first_team_losses_query);
    $first_team_losses = $first_team_losses_result->fetch_assoc()['losses'];

    $second_team_wins_query = "SELECT 
        COUNT(*) AS wins
        FROM results
        WHERE (home_team = '$second_team' AND home_score > away_score) 
        OR (away_team = '$second_team' AND away_score > home_score)";
    $second_team_wins_result = $conn->query($second_team_wins_query);
    $second_team_wins = $second_team_wins_result->fetch_assoc()['wins'];

    $second_team_losses_query = "SELECT 
        COUNT(*) AS losses
        FROM results
        WHERE (home_team = '$second_team' AND home_score < away_score) 
        OR (away_team = '$second_team' AND away_score < home_score)";
    $second_team_losses_result = $conn->query($second_team_losses_query);
    $second_team_losses = $second_team_losses_result->fetch_assoc()['losses'];

    // Calculate average score difference for the first team
    $average_score_difference_query = "SELECT 
        AVG(ABS(home_score - away_score)) AS average_score_difference
        FROM results
        WHERE home_team = '$first_team'";
    $average_score_difference_result = $conn->query($average_score_difference_query);
    $average_score_difference = $average_score_difference_result->fetch_assoc()['average_score_difference'];

    // Calculate the winning difference (example logic)
    $winning_difference = $first_team_wins - $first_team_losses;

    // Assign points based on rank (example logic)
    function assignPointsBasedOnRank($rank) {
        if ($rank >= 1 && $rank <= 10) {
            return 100;
        } elseif ($rank >= 11 && $rank <= 20) {
            return 90;
        } elseif ($rank >= 21 && $rank <= 30) {
            return 80;
        } elseif ($rank >= 31 && $rank <= 40) {
            return 70;
        } elseif ($rank >= 41 && $rank <= 50) {
            return 60;
        } else {
            return 30;
        }
    }

    // Example usage to fetch ranks (replace with actual rank logic)
    $first_team_rank = assignPointsBasedOnRank(15); // Replace with actual rank fetch logic

    // Calculate winning percentages for each team
    $first_team_percentage = (($first_team_total_matches + $first_team_total_goals + $first_team_tournament_matches + $winning_difference + $first_team_rank + $average_score_difference) / 6);
    $second_team_percentage = (($second_team_total_matches + $second_team_total_goals + $second_team_tournament_matches + $second_team_wins + $second_team_losses) / 6);

    // Ensure the total percentage does not exceed 100
    if ($first_team_percentage + $second_team_percentage > 100) {
        $total_percentage = $first_team_percentage + $second_team_percentage;
        $first_team_percentage = ($first_team_percentage / $total_percentage) * 100;
        $second_team_percentage = ($second_team_percentage / $total_percentage) * 100;
    }

    // Calculate draw percentage
    $draw_percentage = 100 - ($first_team_percentage + $second_team_percentage);

    return [
        'first_team_percentage' => $first_team_percentage,
        'second_team_percentage' => $second_team_percentage,
        'draw_percentage' => $draw_percentage,
        'first_team_total_matches' => $first_team_total_matches,
        'first_team_total_goals' => $first_team_total_goals,
        'first_team_tournament_matches' => $first_team_tournament_matches,
        'first_team_wins' => $first_team_wins,
        'first_team_losses' => $first_team_losses,
        'average_score_difference' => $average_score_difference,
        'winning_difference' => $winning_difference,
        'first_team_rank' => $first_team_rank,
        'second_team_total_matches' => $second_team_total_matches,
        'second_team_total_goals' => $second_team_total_goals,
        'second_team_tournament_matches' => $second_team_tournament_matches,
        'second_team_wins' => $second_team_wins,
        'second_team_losses' => $second_team_losses
    ];
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['first_team']) && isset($_POST['second_team'])) {
    $first_team = $conn->real_escape_string($_POST['first_team']);
    $second_team = $conn->real_escape_string($_POST['second_team']);

    if ($first_team === $second_team) {
        echo json_encode(['error' => 'Please select different teams.']);
        exit;
    }

    $prediction = calculatePrediction($first_team, $second_team);
    echo json_encode($prediction);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Soccer Match Predictor</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Soccer Match Predictor</h1>
    <form id="predictionForm" method="POST">
        <label for="first_team">First Team:</label>
        <select name="first_team" id="first_team">
            <?php
            $options = fetchTeamOptions();
            foreach ($options as $option) {
                echo "<option value=\"$option\">$option</option>";
            }
            ?>
        </select>
        <br>
        <label for="second_team">Second Team:</label>
        <select name="second_team" id="second_team">
            <?php
            foreach ($options as $option) {
                echo "<option value=\"$option\">$option</option>";
            }
            ?>
        </select>
        <br>
        <button type="submit">Predict</button>
    </form>
    <div id="result"></div>
    <script>
        document.getElementById('predictionForm').addEventListener('submit', function(event) {
            event.preventDefault();
            var firstTeam = document.getElementById('first_team').value;
            var secondTeam = document.getElementById('second_team').value;

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'first_team=' + encodeURIComponent(firstTeam) + '&second_team=' + encodeURIComponent(secondTeam),
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    document.getElementById('result').innerHTML = `<p>${data.error}</p>`;
                } else {
                    document.getElementById('result').innerHTML = `
                        <p>First Team Winning Percentage: ${data.first_team_percentage}%</p>
                        <p>Second Team Winning Percentage: ${data.second_team_percentage}%</p>
                        <p>Draw Percentage: ${data.draw_percentage}%</p>
                    `;
                }
            });
        });
    </script>
</body>
</html>
